package br.com.bandtec.scrolleclienterest_turmaa

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiFilmesRequests {

    @GET("/filmes")
    fun getFilmes(): Call<List<Filme>>

    @GET("/filmes/{id}")
    fun getFilme(@Path("id") id:Integer): Call<Filme>
}